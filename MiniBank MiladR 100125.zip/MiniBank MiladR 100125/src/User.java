import java.util.ArrayList;
import java.util.List;

public class User {
    private String personalId;
    private String pin;
    private List<Account> accounts;

    public User(String personalId, String pin) {
        this.personalId = personalId;
        this.pin = pin;
        this.accounts = new ArrayList<>();
        accounts.add(new Account("Salary"));
        accounts.add(new Account("Savings"));
    }

    public String getPersonalId() {
        return personalId;
    }

    public boolean verifyPin(String inputPin) {
        return pin.equals(inputPin);
    }

    public List<Account> getAccounts() {
        return accounts;
    }
}
