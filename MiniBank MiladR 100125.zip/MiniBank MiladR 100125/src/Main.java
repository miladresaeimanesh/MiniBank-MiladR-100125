import java.util.Scanner;

public class Main {
    private static Bank bank = new Bank(); // The Bank class will manage users and accounts.
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("Welcome to Minibank!");
            System.out.println("1. Create User");
            System.out.println("2. Log In");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1 -> createUser();
                case 2 -> loginUser();
                case 3 -> {
                    System.out.println("Thank you for using Minibank!");
                    System.exit(0);
                }
                default -> System.out.println("Invalid choice. Please try again.");
            }
        }
    }


    private static void createUser() {
        System.out.print("Enter Personal ID: ");
        String personalId = scanner.next();
        System.out.print("Enter a 4-digit PIN: ");
        String pin = scanner.next();
        bank.createUser(personalId, pin); // Calls Bank's method to create a new user.
    }

    private static void loginUser() {
        System.out.print("Enter Personal ID: ");
        String personalId = scanner.next();
        System.out.print("Enter PIN: ");
        String pin = scanner.next();

        if (bank.authenticateUser(personalId, pin)) {
            userMenu(personalId);
        } else {
            System.out.println("Authentication failed. Please try again.");
        }
    }

    private static void userMenu(String personalId) {
        while (true) {
            System.out.println("\nLogged in as: " + personalId);
            System.out.println("1. View Accounts");
            System.out.println("2. Transfer Money");
            System.out.println("3. Log Out");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1 -> bank.viewAccounts(personalId);
                case 2 -> transferMoney(personalId);
                case 3 -> {
                    System.out.println("Logged out.");
                    return;
                }
                default -> System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void transferMoney(String personalId) {
        System.out.print("Enter source account number: ");
        String fromAccount = scanner.next();
        System.out.print("Enter target account number: ");
        String toAccount = scanner.next();
        System.out.print("Enter amount to transfer: ");
        double amount = scanner.nextDouble();

        if (bank.transfer(personalId, fromAccount, toAccount, amount)) {
            System.out.println("Transfer successful.");
        } else {
            System.out.println("Transfer failed. Please check the details and try again.");
        }
    }
}
