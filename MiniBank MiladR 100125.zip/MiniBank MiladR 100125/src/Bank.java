import java.util.HashMap;
import java.util.Map;

public class Bank {
    private Map<String, User> users;

    public Bank() {
        this.users = new HashMap<>();
    }

    public void createUser(String personalId, String pin) {
        if (users.containsKey(personalId)) {
            System.out.println("User already exists!");
        } else {
            users.put(personalId, new User(personalId, pin));
            System.out.println("User created successfully.");
        }
    }

    public boolean authenticateUser(String personalId, String pin) {
        User user = users.get(personalId);
        return user != null && user.verifyPin(pin);
    }

    public void viewAccounts(String personalId) {
        User user = users.get(personalId);
        if (user != null) {
            System.out.println("Accounts:");
            for (Account account : user.getAccounts()) {
                System.out.println(account.getAccountType() + " - " + account.getAccountNumber() + " - Balance: " + account.getBalance());
            }
        }
    }

    public boolean transfer(String personalId, String fromAccount, String toAccount, double amount) {
        User user = users.get(personalId);
        if (user != null) {
            Account source = null, target = null;
            for (Account account : user.getAccounts()) {
                if (account.getAccountNumber().equals(fromAccount)) {
                    source = account;
                }
                if (account.getAccountNumber().equals(toAccount)) {
                    target = account;
                }
            }
            if (source != null && target != null && source.withdraw(amount)) {
                target.deposit(amount);
                return true;
            }
        }
        return false;
    }
}
