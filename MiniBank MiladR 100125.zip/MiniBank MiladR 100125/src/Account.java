import java.util.UUID;

public class Account {
    private String accountNumber;
    private String accountType;
    private double balance;

    public Account(String accountType) {
        this.accountNumber = UUID.randomUUID().toString().substring(0, 8); // Simple account number generation.
        this.accountType = accountType;
        this.balance = 0.0; // Initial balance.
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getAccountType() {
        return accountType;
    }

    public double getBalance() {
        return balance;
    }

    public void deposit(double amount) {
        balance += amount;
    }

    public boolean withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
            return true;
        }
        return false;
    }
}
